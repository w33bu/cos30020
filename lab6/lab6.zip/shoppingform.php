<!DOCTYPE html> 
<html lang="en"> 
<head> 
  <meta charset="utf-8" /> 
  <meta name="description" content="Web application development" /> 
  <meta name="keywords" content="PHP" /> 
  <meta name="author"   content="Your Name" /> 
  <title>TITLE</title> 
</head> 
<body> 
<h1>Web Programming Form – Lab06</h1> 
<form action = "shoppingsave.php" method = "post"> 
Enter the name: <input type="text" name="item">   
Enter the quantity: <input type="number" name="qty">  
<input type="submit" name="submit" value="Submit"> 
</form> 
</body> 
</html> 