<!DOCTYPE html> 
<html lang="en"> 
<head> 
  <meta charset="utf-8" /> 
  <meta name="description" content="Web application development" /> 
  <meta name="keywords" content="PHP" /> 
  <meta name="author"   content="Your Name" /> 
  <title>TITLE</title> 
</head> 
<body> 
<h1>Lab 5 Task 2 - Guestbook</h1> 
<h2>Enter your details to sign our guest book</h2>
<form action = "guestbooksave.php" method = "post"> 
First name: <input type="text" name="first">   
Last name: <input type="text" name="last">  
<input type="submit" name="submit" value="Submit"> 
</form> 
</body> 
</html> 