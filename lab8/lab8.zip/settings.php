<?php 
$host = "feenix-mariadb.swin.edu.au"; 
$user = "s103582323"; // your user name 
$pswd = "010302"; // your password d(date of birth – ddmmyy) 
$dbnm = "s103582323_db"; // your database 
?> 