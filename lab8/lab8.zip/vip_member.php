<!DOCTYPE html> 
<html lang="en"> 
<head> 
  <meta charset="utf-8" /> 
  <meta name="description" content="Web application development" /> 
  <meta name="keywords" content="PHP" /> 
  <meta name="author"   content="Your Name" /> 
  <title>Home Page</title> 
</head> 
<body>
	<h1>welcome</h1>
	<a href='member_add_form.php'>add new menber form</a><br />
	<a href='member_display.php'>display all menber page</a><br />
	<a href='member_search.php'>search member page</a>